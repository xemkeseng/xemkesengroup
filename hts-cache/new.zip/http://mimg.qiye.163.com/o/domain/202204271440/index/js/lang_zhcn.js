var message = {
	telecom: '电信',
	unicom: '联通',
	hangzhou: '华东互通',
	server: '服务器：',
	connecting: '连接中',
	networkCheck: '网络测速'
};